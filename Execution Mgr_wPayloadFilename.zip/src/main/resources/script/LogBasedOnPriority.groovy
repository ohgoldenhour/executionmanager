import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import groovy.json.*;
import java.util.regex.*;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def properties = message.getProperties();
    //def headers = message.getHeaders();
    //def iFlowLogPriority = headers.get('iFlowLogPriority');
    def iFlowLogPriority = properties.get('iFlowLogPriority');
    def messageLog = messageLogFactory.getMessageLog(message);
 
	def logTitle = properties.get("logTitle");
	def logType = properties.get("logType");
	def logPriority = properties.get("logPriority");	
	def exceptionMessage = properties.get("ExceptionMessage");
    
    String logMessage = "";
    String logMessageType = "text/plain";
    
    if(iFlowLogPriority <= logPriority){

     switch(logType.toLowerCase()) {            
         //There is case statement defined for 4 cases 
         // Each case statement section has a break condition to exit the loop 
			
         case 'xml': 
            XmlUtil xmlUtil = new XmlUtil();
    		def xmldoc = new XmlParser().parseText(body);
    		def serialized = XmlUtil.serialize(xmldoc);
    		serialized = serialized.replaceAll('<\\?xml version="1.0" encoding="UTF-8"\\?>', '<\\?xml version="1.0" encoding="UTF-8"\\?> \n');
    		logMessage = serialized;     
            break; 
         case 'json': 
          	def json = new JsonSlurper().parseText(body);
          	json.each { 
			  logMessage = logMessage + JsonOutput.prettyPrint(JsonOutput.toJson(it));
			}
            break; 
         case 'csv':
         	logMessage = body;
         	break;
         default: 
            String defaultMessage = body ? body: exceptionMessage;
           	logMessage = defaultMessage.replaceAll("(.{100})(\\s+|\\Z)","\$1\n");
            break; 
      }
        body = logMessage;      
        if(messageLog != null){
    	    if(logTitle != null && logMessage != null && logMessageType != null){
        	    messageLog.addAttachmentAsString(logTitle, logMessage, logMessageType);
        }else{
 	    	    messageLog.addAttachmentAsString("Warning: one of required log parameters not set", "logTitle: "+logTitle+" logMessage: " + logMessage + "logMessageType: " +logMessageType+ "\n \n"+ body, 'text/plain');
 		}
        }
    }
    return message;
}